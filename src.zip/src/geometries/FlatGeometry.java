package geometries;


public abstract class FlatGeometry  extends Geometry{

}
